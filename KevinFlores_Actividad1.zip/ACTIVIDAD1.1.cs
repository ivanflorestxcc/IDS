﻿using System;

class Program
{
    static void Main()
    {
        // 1. Mensaje de bienvenida
        Console.WriteLine("Bienvenidos a UMI/Universidad Coppel\n");

        // 2. Solicitar los datos
        Console.Write("Ingrese su nombre completo: ");
        string nombreCompleto = Console.ReadLine();

        Console.Write("Ingrese su edad: ");
        string edad = Console.ReadLine();

        Console.Write("Ingrese su fecha de nacimiento (dd/mm/aaaa): ");
        string fechaNacimiento = Console.ReadLine();

        Console.Write("Ingrese la carrera a la que desea ingresar: ");
        string carrera = Console.ReadLine();

        // 4. Mensaje de agradecimiento personalizado
        Console.WriteLine($"\nGracias {nombreCompleto} por formar parte de UMI/Universidad Coppel, Bienvenido a la carrera {carrera}.");

        // 5. Mostrar todos los datos ingresados
        Console.WriteLine("\n--- Datos del Aspirante ---");
        Console.WriteLine($"Nombre Completo: {nombreCompleto}");
        Console.WriteLine($"Edad: {edad}");
        Console.WriteLine($"Fecha de Nacimiento: {fechaNacimiento}");
        Console.WriteLine($"Carrera: {carrera}");

        // Para que la consola no se cierre automáticamente
        Console.WriteLine("\nPresione cualquier tecla para salir...");
        Console.ReadKey();
    }
}