namespace actividad_1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtNacimiento = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstEstados = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioVespertino = new System.Windows.Forms.RadioButton();
            this.radioMatutino = new System.Windows.Forms.RadioButton();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDireccion);
            this.groupBox1.Controls.Add(this.txtNacimiento);
            this.groupBox1.Controls.Add(this.txtNombre);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 120);
            this.groupBox1.Text = "Datos del Alumno";
            // 
            // Labels and TextBoxes
            // 
            this.label1.Text = "Nombre completo";
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.txtNombre.Location = new System.Drawing.Point(120, 20);
            this.txtNombre.Width = 120;

            this.label2.Text = "Fecha de nacimiento";
            this.label2.Location = new System.Drawing.Point(6, 50);
            this.txtNacimiento.Location = new System.Drawing.Point(120, 50);
            this.txtNacimiento.Width = 120;

            this.label3.Text = "Dirección";
            this.label3.Location = new System.Drawing.Point(6, 80);
            this.txtDireccion.Location = new System.Drawing.Point(120, 80);
            this.txtDireccion.Width = 120;
            // 
            // lstEstados
            // 
            this.lstEstados.FormattingEnabled = true;
            this.lstEstados.Location = new System.Drawing.Point(12, 140);
            this.lstEstados.Name = "lstEstados";
            this.lstEstados.Size = new System.Drawing.Size(250, 95);
            // 
            // groupBox2 (Horarios)
            // 
            this.groupBox2.Controls.Add(this.radioVespertino);
            this.groupBox2.Controls.Add(this.radioMatutino);
            this.groupBox2.Location = new System.Drawing.Point(280, 12);
            this.groupBox2.Size = new System.Drawing.Size(120, 80);
            this.groupBox2.Text = "Horarios";

            this.radioMatutino.Text = "Matutino";
            this.radioMatutino.Location = new System.Drawing.Point(10, 20);

            this.radioVespertino.Text = "Vespertino";
            this.radioVespertino.Location = new System.Drawing.Point(10, 45);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.Location = new System.Drawing.Point(300, 210);
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(420, 260);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lstEstados);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnGuardar);
            this.Text = "Expediente de alumno";
            this.Icon = new System.Drawing.Icon(System.Reflection.Assembly
    .GetExecutingAssembly()
    .GetManifestResourceStream("actividad_1.Resources.images.ico"));
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtNacimiento;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstEstados;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioVespertino;
        private System.Windows.Forms.RadioButton radioMatutino;
        private System.Windows.Forms.Button btnGuardar;
    }
}
