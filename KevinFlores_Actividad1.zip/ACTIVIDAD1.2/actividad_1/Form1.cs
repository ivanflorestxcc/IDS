using System;
using System.Windows.Forms;

namespace actividad_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] estados = {
                "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas",
                "Chihuahua", "Ciudad de México", "Coahuila", "Colima", "Durango", "Estado de México",
                "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Michoacán", "Morelos", "Nayarit",
                "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí",
                "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas"
            };

            lstEstados.Items.AddRange(estados);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string nacimiento = txtNacimiento.Text;
            string direccion = txtDireccion.Text;
            string estado = lstEstados.SelectedItem?.ToString() ?? "No seleccionado";
            string horario = radioMatutino.Checked ? "Matutino" : (radioVespertino.Checked ? "Vespertino" : "No seleccionado");

            MessageBox.Show($"Datos guardados:\n\nNombre: {nombre}\nFecha de nacimiento: {nacimiento}\nDirección: {direccion}\nEstado: {estado}\nHorario: {horario}",
                            "Expediente Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
